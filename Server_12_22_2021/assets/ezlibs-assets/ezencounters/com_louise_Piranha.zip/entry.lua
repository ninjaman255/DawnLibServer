local package_id = "com.louise.Piranha"
local character_id = "com.louise.enemy."

function package_requires_scripts()
  Engine.define_character(character_id .. "Piranha", _modpath .. "Piranha")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("Piranha")
  package:set_description("Bn6 Piranha")
  package:set_speed(1)
  package:set_attack(20)
  package:set_health(70)
  package:set_preview_texture_path(_modpath .. "preview.png")
end

function package_build(mob)
  local spawner = mob:create_spawner(character_id .. "Piranha", Rank.V1)
  spawner:spawn_at(4, 1)
  local spawner = mob:create_spawner(character_id .. "Piranha", Rank.V2)
  spawner:spawn_at(5, 2)
  local spawner = mob:create_spawner(character_id .. "Piranha", Rank.V3)
  spawner:spawn_at(6, 3)
  -- local spawner = mob:create_spawner(character_id .. "Piranha", Rank.SP)
  -- spawner:spawn_at(4, 2)
  -- local spawner = mob:create_spawner(character_id .. "Piranha", Rank.Rare1)
  -- spawner:spawn_at(5, 3)
  -- local spawner = mob:create_spawner(character_id .. "Piranha", Rank.Rare2)
  -- spawner:spawn_at(6, 1)
  -- local spawner = mob:create_spawner(character_id .. "Piranha", Rank.NM)
  -- spawner:spawn_at(4, 3)
end
