local battle_helpers = include("battle_helpers.lua")
local character_animation = _folderpath .. "battle.animation"
local anim_speed = 1
local neddle_texture = Engine.load_texture(_folderpath .. "needle.png")
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.greyscaled.png")
local needle_anim = _folderpath .. "needle.animation"
local barrier_chip = include("barrier100/entry.lua")
local shoot_sfx = Engine.load_audio(_folderpath .. "puffyshoot.ogg")
local impact_sfx = Engine.load_audio(_folderpath .. "puffyimpact.ogg")
local redtint = Color.new(140, 0, 0, 255)

--possible states for character
-- level is based on how many needles puffy shoots.
local states = { LEVEL_1 = 1, LEVEL_2 = 2, LEVEL_3 = 3 }
-- Load character resources
local puffyCount = 0

---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information

    local base_animation_path = character_animation
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    self.animation:set_playback_speed(anim_speed)
    -- Load extra resources
    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self.damage = (character_info.damage)
    self:share_tile(false)
    self:set_explosion_behavior(4, 1, false)
    self:set_offset(0, 0)
    --fish are aqua
    self:set_element(Element.Aqua)
    self:set_palette(Engine.load_texture(character_info.palette))
    self.has_barrier = (character_info.has_barrier)

    self.frame_counter = 0
    self.frames_between_actions = character_info.frames_between_actions
    self.started = false
    self.attack_count = 0
    self.animation:set_state("LEVEL1_IDLE")
    self.animation:set_playback(Playback.Loop)
    self.move_direction = Direction.Right
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    self.defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always)
    self.defense_rule.can_block_func = function(judge, attacker, defender)
        if (not judge:is_damage_blocked()) then
            self.inflate = true
        end

    end

    self:add_defense_rule(self.defense_rule)

    -- actions for states


    self.action_level1 = function(frame)
        if (frame == self.frames_between_actions) then
            self.animation:set_state("LEVEL1_ATTACK")
            self.tint = true
            self:toggle_counter(true)
            self.animation:on_complete(function()
                Engine.play_audio(shoot_sfx, AudioPriority.High)
                local target_tiles = find_tiles(self)
                for index, value in pairs(target_tiles) do
                    toss_spell(self, 200, neddle_texture, needle_anim, value, 40, function()
                    end)
                end
                self:toggle_counter(false)
                self.animation:set_state("LEVEL1_IDLE")
                self.tint = false
                self.animation:set_playback(Playback.Loop)
                self.frame_counter = 0
                if (self.has_barrier) then
                    local props = {}
                    props.time_freeze = true
                    local barr = barrier_chip.card_create_action(self, props)
                    self:card_action_event(barr, ActionOrder.Involuntary)
                    self.has_barrier = false
                end
            end)
        end
        if (self.inflate) then
            self.set_state(states.LEVEL_2, true)
            self.inflate = false;
        end
    end

    self.action_level2 = function(frame)
        if (frame == self.frames_between_actions) then
            self:toggle_counter(true)
            self.animation:set_state("LEVEL2_ATTACK")
            self.tint = true
            self.animation:on_complete(function()
                self:needle_attack()
            end)
        end
        if (frame == self.frames_between_actions + 40) then
            self:toggle_counter(false)
            self:needle_attack()
            self.animation:set_state("LEVEL2_IDLE")
            self.animation:set_playback(Playback.Loop)
            self.tint = false
            self.frame_counter = 0

        end
        if (self.inflate) then
            self.set_state(states.LEVEL_3, true)
            self.inflate = false;
        end
    end

    self.action_level3 = function(frame)
        if (frame == self.frames_between_actions) then
            self:toggle_counter(true)
            self.animation:set_state("LEVEL3_ATTACK")
            self.tint = true
            self.animation:on_complete(function()
                self:needle_attack()
            end)
        end
        if (frame == self.frames_between_actions + 20) then
            self:toggle_counter(false)
            self:needle_attack()
        else if (frame == self.frames_between_actions + 40) then
                self:needle_attack()
                self.animation:set_state("LEVEL3_IDLE")
                self.animation:set_playback(Playback.Loop)
                self.tint = false
                self.frame_counter = 0

            end
        end
    end

    self.needle_attack = function(self)
        Engine.play_audio(shoot_sfx, AudioPriority.High)
        local target_tiles = find_tiles(self)
        for index, value in pairs(target_tiles) do
            toss_spell(self, 200, neddle_texture, needle_anim, value, 40, function()
            end)
        end
    end

    self.on_spawn_func = function(self)
        puffyCount = puffyCount + 1
        self.start_delay = puffyCount * 20
        -- accounts for escape button presses
        -- to avoid delays on later battles
        if (puffyCount > 4) then
            puffyCount = -1
        end
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state, no_reset)
        self.state = state
        if (not no_reset) then
            self.frame_counter = 0
        end
    end

    local actions = { [1] = self.action_level1, [2] = self.action_level2, [3] = self.action_level3, }

    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            if self.frame_counter > self.start_delay then
                self.current_direction = self:get_facing()
                self.enemy_dir = self:get_facing()
                self.started = true
                self.set_state(states.LEVEL_1)
                self.tint = false
            end
        else
            if (self.tint) then
                self:sprite():set_color(redtint)
            end
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end

    end

    function toss_spell(tosser, toss_height, texture, animation_path, target_tile, frames_in_air, arrival_callback)
        local starting_height = -110
        local start_tile = tosser:get_current_tile()

        local field = tosser:get_field()
        local spell = Battle.Spell.new(tosser:get_team())
        local spell_animation = spell:get_animation()
        spell_animation:load(animation_path)
        spell_animation:set_state("DEFAULT")
        spell_animation:set_playback_speed(0.5)
        if tosser:get_height() > 1 then
            starting_height = -(tosser:get_height())
        end
        spell:set_hit_props(
            HitProps.new(
                tosser.damage,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                tosser:get_element(),
                tosser:get_context(),
                Drag.None
            )
        )
        spell.jump_started = false
        spell.starting_y_offset = starting_height
        spell.starting_x_offset = 10
        if tosser:get_facing() == Direction.Left then
            spell.starting_x_offset = -10
        end
        spell.y_offset = spell.starting_y_offset
        spell.x_offset = spell.starting_x_offset
        local sprite = spell:sprite()
        sprite:set_texture(texture)
        spell:set_offset(spell.x_offset, spell.y_offset)

        spell.update_func = function(self)
            target_tile:highlight(Highlight.Solid)
            if not spell.jump_started then
                self:jump(target_tile, toss_height, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
                self.jump_started = true
            end
            if self.y_offset < 0 then
                self.y_offset = self.y_offset + math.abs(self.starting_y_offset / frames_in_air)
                self.x_offset = self.x_offset - math.abs(self.starting_x_offset / frames_in_air)
                self:set_offset(self.x_offset, self.y_offset)
            else
                arrival_callback()
                self:get_current_tile():attack_entities(self)
                Engine.play_audio(impact_sfx, AudioPriority.Highest)
                self:delete()
            end
        end
        spell.attack_func = function(self, other)

        end
        spell.can_move_to_func = function(tile)
            return true
        end
        field:spawn(spell, start_tile)
    end

    function find_tiles(self)
        local target_char = find_target(self)
        if (not target_char) then
            return {}
        end
        local target_tile = target_char:get_tile()
        local tilePatterns = {}
        local team = self:get_team()
        local enemy_field = getEnemyField(team, target_tile, self:get_field())
        shuffle(enemy_field)
        --targets will always contain the target tile, plus extras.
        table.insert(tilePatterns, target_tile)
        return tilePatterns
    end

    --get the enemy field, besides the target tile.
    function getEnemyField(team, target_tile, field)
        local tile_arr = {}
        for i = 1, 6, 1 do
            for j = 1, 3, 1 do
                local tile = field:tile_at(i, j)
                if (tile ~= target_tile and tile:get_team() ~= team) then
                    table.insert(tile_arr, tile)
                end
            end
        end
        return tile_arr
    end

    --find a target character
    function find_target(self)
        local field = self:get_field()
        local team = self:get_team()
        local target_list = field:find_characters(function(other_character)
            return other_character:get_team() ~= team
        end)
        if #target_list == 0 then
            return
        end
        local target_character = target_list[1]
        return target_character
    end

    function tiletostring(tile)
        return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
    end

    --shuffle function to provide some randomness
    function shuffle(tbl)
        for i = #tbl, 2, -1 do
            local j = math.random(i)
            tbl[i], tbl[j] = tbl[j], tbl[i]
        end
        return tbl
    end


end

return package_init
