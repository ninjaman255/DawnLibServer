local shared_package_init = include("./character.lua")
function package_init(character)
    local character_info = {
        name = "Puffy",
        hp = 80,
        damage = 10,
        palette = _folderpath .. "V1.png",
        height = 44,
        frames_between_actions = 88,
        element = Element.None,
    }
    if character:get_rank() == Rank.V2 then
        character_info.hp = 120
        character_info.damage = 30
        character_info.palette = _folderpath .. "V2.png"
    end
    if character:get_rank() == Rank.V3 then
        character_info.hp = 200
        character_info.damage = 80
        character_info.palette = _folderpath .. "V3.png"
    end
    if character:get_rank() == Rank.SP then
        character_info.hp = 240
        character_info.damage = 100
        character_info.palette = _folderpath .. "SP.png"
        character_info.has_barrier = true
    end
    if character:get_rank() == Rank.Rare1 then
        character_info.hp = 170
        character_info.damage = 100
        character_info.palette = _folderpath .. "Rare1.png"
    end
    if character:get_rank() == Rank.Rare2 then
        character_info.hp = 250
        character_info.damage = 130
        character_info.palette = _folderpath .. "Rare2.png"
        character_info.has_barrier = true
    end
    shared_package_init(character, character_info)
end
