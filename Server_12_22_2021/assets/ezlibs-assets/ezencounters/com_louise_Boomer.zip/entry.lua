local package_id = "com.louise.Boomer"
local character_id = "com.louise.enemy."

-- To spawn this enemy use
-- com.louise.enemy.Boomer
-- com.louise.enemy.Gloomer
-- com.louise.enemy.Doomer

function package_requires_scripts()
  Engine.define_character(character_id .. "Boomer", _modpath .. "Boomer")
  Engine.define_character(character_id .. "Gloomer", _modpath .. "Gloomer")
  Engine.define_character(character_id .. "Doomer", _modpath .. "Doomer")
end

function package_init(package)
  package:declare_package_id(package_id)
  package:set_name("Boomer")
  package:set_description("Bn3 Boomer")
  package:set_speed(1)
  package:set_attack(60)
  package:set_health(80)
  package:set_preview_texture_path(_modpath .. "preview.png")
end

function package_build(mob)
  local spawner = mob:create_spawner(character_id .. "Boomer", Rank.SP)
  spawner:spawn_at(4, 1)

  -- local spawner = mob:create_spawner(character_id .. "Boomer", Rank.Rare1)
  -- spawner:spawn_at(5, 2)

  -- local spawner = mob:create_spawner(character_id .. "Boomer", Rank.Rare2)
  -- spawner:spawn_at(6, 3)


  local spawner = mob:create_spawner(character_id .. "Gloomer", Rank.V1)
  spawner:spawn_at(5, 2)

  local spawner = mob:create_spawner(character_id .. "Doomer", Rank.V1)
  spawner:spawn_at(6, 3)
end
