local shared_package_init = include("../HardHead/character.lua")
local character_id = "com.louise.enemy."
function package_init(character)
    local character_info = {
        name = "HotHead",
        hp = 200,
        damage = 100,
        palette = _folderpath .. "palette.png",
        height = 44,
        cornshots = 1,
        move_speed = 16,
        frames_between_actions = 86,
        element = Element.Fire,
        tile_type = TileState.Lava
    }

    shared_package_init(character, character_info)
end
