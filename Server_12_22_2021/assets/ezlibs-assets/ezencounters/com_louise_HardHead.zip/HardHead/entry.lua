local shared_package_init = include("./character.lua")
local character_id = "com.louise.enemy."
function package_init(character)
    local character_info = {
        name = "HardHead",
        hp = 80,
        damage = 60,
        palette = _folderpath .. "V1.png",
        height = 44,
        frames_between_actions = 200,
        element = Element.None,
        tile_type = TileState.Broken
    }
    if character:get_rank() == Rank.SP then
        character_info.damage = 200
        character_info.palette = _folderpath .. "SP.png"
        character_info.hp = 300
    end
    if character:get_rank() == Rank.NM then
        character_info.damage = 300
        character_info.palette = _folderpath .. "NM.png"
        character_info.hp = 500
        character_info.frames_between_actions = 10
        character_info.tile_type = TileState.Poison
        character_info.has_areagrab = true
    end
    shared_package_init(character, character_info)
end
