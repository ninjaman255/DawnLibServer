local battle_helpers = include("battle_helpers.lua")
local character_animation = _folderpath .. "battle.animation"
local anim_speed = 1
local shoot_sfx = Engine.load_audio(_folderpath .. "cannon.ogg")
local crack_sfx = Engine.load_audio(_folderpath .. "crack.ogg")
local ice_sfx = Engine.load_audio(_folderpath .. "freeze.ogg")
local fire_sfx = Engine.load_audio(_folderpath .. "fire.ogg")
local ball_texture = Engine.load_texture(_folderpath .. "ball.png")
local CHARACTER_TEXTURE = Engine.load_texture(_folderpath .. "battle.greyscaled.png")
local ball_anim = _folderpath .. "ball.animation"
local areagrab_chip = include("AreaGrab/entry.lua")

--possible states for character
local states = { IDLE = 1, BEGIN_OPEN = 2, OPEN = 3, SHOOT = 4, CLOSE = 5 }
-- Load character resources
local hardHeadCount = -1

---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information

    local base_animation_path = character_animation
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)
    self.animation:set_playback_speed(anim_speed)
    -- Load extra resources
    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self.hop_time = (character_info.move_speed)
    self.damage = (character_info.damage)
    self:share_tile(false)
    self:set_explosion_behavior(4, 1, false)
    self:set_offset(0, 0)
    self:set_element(character_info.element)
    --different attacks per enemy type set here!
    if (self:get_element() == Element.Fire) then
        self.breakfx = fire_sfx
        self.attack_texture = "FIRE"
    elseif (self:get_element() == Element.Aqua) then
        self.breakfx = ice_sfx
        self.attack_texture = "ICE"
    else
        self.breakfx = crack_sfx
        self.attack_texture = "NORMAL"
    end

    self.tile_type = character_info.tile_type
    if (self.tile_type == TileState.Poison) then
        self.breakfx = fire_sfx
    end
    self:set_palette(Engine.load_texture(character_info.palette))
    self.has_areagrab = (character_info.has_areagrab)
    self.animation:set_state("IDLE")
    self.frame_counter = 0
    self.frames_between_actions = character_info.frames_between_actions
    self.started = false
    self.attack_count = 0

    self.move_direction = Direction.Right
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    self.defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
    local defense_texture = Engine.load_texture(_folderpath .. "guard_hit.png")
    local defense_animation = _folderpath .. "guard_hit.animation"
    local defense_audio = Engine.load_audio(_folderpath .. "tink.ogg", true)
    self.defense_rule.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()

        if (self.state == nil or self.state == states.IDLE or self.state == states.BEGIN_OPEN) then

            if attacker_hit_props.flags & Hit.Breaking == Hit.Breaking then
                --cant block breaking hits
                return
            end
            judge:block_impact()
            judge:block_damage()
            local artifact = Battle.Spell.new(self:get_team())
            artifact:set_texture(defense_texture)
            local anim = artifact:get_animation()
            anim:load(defense_animation)
            anim:set_state("DEFAULT")
            anim:refresh(artifact:sprite())
            anim:on_complete(function()
                artifact:erase()
            end)
            self:get_field():spawn(artifact, self:get_tile())
            Engine.play_audio(defense_audio, AudioPriority.High)
        end
    end
    self:add_defense_rule(self.defense_rule)

    -- actions for states


    self.action_idle = function(frame)
        if (frame == self.frames_between_actions) then
            self.set_state(states.BEGIN_OPEN)
        end
    end
    ---hardHead shoot
    ---@param frame number
    self.action_beginopen = function(frame)
        if (frame == 1) then
            self.animation:set_state("OPENING")
            self.animation:set_playback(Playback.Loop)
        elseif (frame == 56 or self:get_rank() == Rank.NM) then
            self.set_state(states.OPEN)
        end
    end

    ---hardHead open
    ---@param frame number
    self.action_open = function(frame)
        if (frame == 1) then
            self.animation:set_state("OPEN")
        elseif (frame == 28) then
            self.set_state(states.SHOOT)
        end
    end

    ---hardHead open
    ---@param frame number
    self.action_shoot = function(frame)
        if (frame == 1) then
            self.animation:set_state("SHOOT")
            self.animation:on_frame(3, function()
                self:toggle_counter(true)
            end)
            self.animation:on_frame(4, function()
                self:toggle_counter(false)
                Engine.play_audio(shoot_sfx, AudioPriority.Highest)
                local target_tiles = find_tiles(self)
                for index, value in pairs(target_tiles) do
                    toss_spell(self, 60, ball_texture, ball_anim, value, 40, function()
                        create_cannonball(self, value, ball_texture, ball_anim, self.breakfx)
                        if (self.attack_count == 4 and self.has_areagrab) then
                            local grab = areagrab_chip.card_create_action(self)
                            self:card_action_event(grab, ActionOrder.Involuntary)
                            self.has_areagrab = false
                        else
                            self.attack_count = self.attack_count + 1
                        end
                    end)
                end
            end)
        elseif (frame == 90) then
            self.set_state(states.CLOSE)
        end
    end

    ---hardHead close
    ---@param frame number
    self.action_close = function(frame)
        if (frame == 1) then
            self.animation:set_state("CLOSE")
            self.animation:on_complete(function()
                self.animation:set_state("IDLE")
                self.set_state(states.IDLE)
            end)
        end
    end
    self.on_spawn_func = function(self)
        hardHeadCount = hardHeadCount + 1
        self.start_delay = hardHeadCount * 90
        -- accounts for escape button presses
        -- to avoid delays on later battles
        if (hardHeadCount > 4) then
            hardHeadCount = -1
        end
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end

    local actions = { [1] = self.action_idle, [2] = self.action_beginopen, [3] = self.action_open,
        [4] = self.action_shoot, [5] = self.action_close }

    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            if self.frame_counter > self.start_delay then
                self.current_direction = self:get_facing()
                self.enemy_dir = self:get_facing()
                self.started = true
                self.set_state(states.IDLE)
            end
        else
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
    end

    function toss_spell(tosser, toss_height, texture, animation_path, target_tile, frames_in_air, arrival_callback)
        local starting_height = -110
        local start_tile = tosser:get_current_tile()

        local field = tosser:get_field()
        local spell = Battle.Spell.new(tosser:get_team())
        local spell_animation = spell:get_animation()
        spell_animation:load(animation_path)
        spell_animation:set_state(tosser.attack_texture)
        spell_animation:set_playback(Playback.Loop)
        if tosser:get_height() > 1 then
            starting_height = -(tosser:get_height())
        end

        spell.jump_started = false
        spell.starting_y_offset = starting_height
        spell.starting_x_offset = 10
        if tosser:get_facing() == Direction.Left then
            spell.starting_x_offset = -10
        end
        spell.y_offset = spell.starting_y_offset
        spell.x_offset = spell.starting_x_offset
        local sprite = spell:sprite()
        sprite:set_texture(texture)
        spell:set_offset(spell.x_offset, spell.y_offset)

        spell.update_func = function(self)
            target_tile:highlight(Highlight.Flash)
            if not spell.jump_started then
                self:jump(target_tile, toss_height, frames(frames_in_air), frames(frames_in_air), ActionOrder.Voluntary)
                self.jump_started = true
            end
            if self.y_offset < 0 then
                self.y_offset = self.y_offset + math.abs(self.starting_y_offset / frames_in_air)
                self.x_offset = self.x_offset - math.abs(self.starting_x_offset / frames_in_air)
                self:set_offset(self.x_offset, self.y_offset)
            else
                arrival_callback()
                self:delete()
            end
        end
        spell.can_move_to_func = function(tile)
            return true
        end
        field:spawn(spell, start_tile)
    end

    ---cannonball attack for hardHead.
    function create_cannonball(user, target_tile, texture, anim_path, explosion_sound)
        local field = user:get_field()
        local spell = Battle.Spell.new(user:get_team())
        local spell_animation = spell:get_animation()
        spell:set_hit_props(
            HitProps.new(
                user.damage,
                Hit.Impact | Hit.Flinch,
                user:get_element(),
                user:get_context(),
                Drag.None
            )
        )
        spell_animation:load(anim_path)
        spell_animation:set_state("POOF")
        spell:set_texture(texture)
        spell:sprite():set_layer(-2)
        spell_animation:refresh(spell:sprite())
        spell_animation:set_playback(Playback.Loop)
        spell.hits = 1
        local do_once = true
        spell.update_func = function(self, dt)
            if do_once then
                spell:get_current_tile():attack_entities(self)
                spell_animation:refresh(spell:sprite())
                spell_animation:on_frame(1, function()
                    target_tile:set_state(user.tile_type)
                end)
                spell_animation:on_frame(8, function()

                    spell:delete()
                end)
                do_once = false
            end
            self:get_current_tile():attack_entities(self)
        end
        Engine.play_audio(explosion_sound, AudioPriority.Highest)
        spell.collision_func = function(self, other)
        end
        spell.attack_func = function(self, other)
        end
        spell.delete_func = function(self)
            self:erase()
        end
        spell.can_move_to_func = function(tile)
            return true
        end
        field:spawn(spell, target_tile)
    end

    function find_tiles(self)
        local target_char = find_target(self)
        if (not target_char) then
            return {}
        end
        local target_tile = target_char:get_tile()
        local tilePatterns = {}
        local team = self:get_team()
        local enemy_field = getEnemyField(team, target_tile, self:get_field())
        shuffle(enemy_field)
        --targets will always contain the target tile, plus extras.
        table.insert(tilePatterns, target_tile)
        return tilePatterns
    end

    --get the enemy field, besides the target tile.
    function getEnemyField(team, target_tile, field)
        local tile_arr = {}
        for i = 1, 6, 1 do
            for j = 1, 3, 1 do
                local tile = field:tile_at(i, j)
                if (tile ~= target_tile and tile:get_team() ~= team) then
                    table.insert(tile_arr, tile)
                end
            end
        end
        return tile_arr
    end

    --find a target character
    function find_target(self)
        local field = self:get_field()
        local team = self:get_team()
        local target_list = field:find_characters(function(other_character)
            return other_character:get_team() ~= team
        end)
        if #target_list == 0 then
            return
        end
        local target_character = target_list[1]
        return target_character
    end

    function tiletostring(tile)
        return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
    end

    --shuffle function to provide some randomness
    function shuffle(tbl)
        for i = #tbl, 2, -1 do
            local j = math.random(i)
            tbl[i], tbl[j] = tbl[j], tbl[i]
        end
        return tbl
    end


end

return package_init
