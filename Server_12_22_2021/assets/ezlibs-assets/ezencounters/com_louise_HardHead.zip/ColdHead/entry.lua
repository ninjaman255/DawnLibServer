local shared_package_init = include("../HardHead/character.lua")
local character_id = "com.louise.enemy."
function package_init(character)
    local character_info = {
        name = "ColdHead",
        hp = 120,
        damage = 100,
        palette = _folderpath .. "palette.png",
        height = 44,
        frames_between_actions = 110,
        element = Element.Aqua,
        tile_type = TileState.Ice
    }

    shared_package_init(character, character_info)
end
