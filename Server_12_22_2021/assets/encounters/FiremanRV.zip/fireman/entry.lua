--Author: Gray Nine
function find_best_target(self)
    local target = self:get_target()
    local field = self:get_field()
    local query = function(c)
        return c:get_team() ~= self:get_team()
    end
    local potential_threats = field:find_characters(query)
    local goal_hp = 99999
    if #potential_threats > 0 then
        for i = 1, #potential_threats, 1 do
            local possible_target = potential_threats[i]
            if possible_target:get_health() <= goal_hp and possible_target:get_health() > 0 then
                target = possible_target
            end
        end
    end
    return target
end

function NextState(self)
    -- increment our AI state counter
    self.aiStateIndex = self.aiStateIndex + 1
    if self.aiStateIndex > 18 then 
        self.aiStateIndex = 1
    end
	self.activate_function_once = true
end

function set_wait_timer(self, seconds) 
    self.waitTime = seconds
	self.firstFrame = true
    NextState(self)
end

function WaitState(self, dt)
	if self.firstFrame then
		self.firstFrame = false
		if not self.ruined then
			self.anim:set_state("IDLE")
			self.anim:set_playback(Playback.Loop)
		end
	end
    if self.waitTime <= 0 then
		if self.ruined then
			self.anim:set_state("IDLE")
			self.anim:set_playback(Playback.Loop)
			self.ruined = false
		end
		NextState(self)
    end
end

function MoveState(self, dt)
	if self.firstFrame then
		local current_tile = self:get_tile()
		local field = self:get_field()
		local moved = false
		local target_tile = nil
		--Nesting bullshit. This reads: If the entity is a character, or if it is an obstacle, then return true that you found it. Filter out anything else.
		local is_occupied = function(ent) if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then return true end end
		local tile_array = {}
		for x = 1, 6, 1 do
			for y = 1, 3, 1 do
				local prospective_tile = field:tile_at(x, y)
				if prospective_tile and self.can_move_to_func(prospective_tile) then table.insert(tile_array, prospective_tile) end
			end
		end
		if #tile_array == 0 then return end
		target_tile = tile_array[math.random(1, #tile_array)]
		if target_tile then
			self.anim:set_state("MOVE")
			self.anim:set_playback(Playback.Once)
			self:teleport(target_tile, ActionOrder.Immediate, nil)
		end
		self.firstFrame = false
	end
	if self.waitTime <= 0 then NextState(self) end
end

function AttackState(self, dt)
	if self.ruined then return end
	if self.firstFrame then
		self.attack = self.attack_order[self.attack_index]
		self.attack_index = self.attack_index + 1
		if self.attack_index > #self.attack_order then self.attack_index = 1 end
		local own_tile = self:get_tile()
		local target = find_best_target(self)
		local field = self:get_field()
		local target_tile = field:tile_at(2, 2)
		if target and not target:is_deleted() then
			target_tile = target:get_tile()
		end
		if self.attack == "FIREARM" and own_tile:y() ~= target_tile:y() then
			local wanted_tile = nil
			local check_x = target_tile:x()
			local y = target_tile:y()
			for x = check_x, 6, 1 do
				local test_tile = field:tile_at(x, y)
				if self.can_move_to_func(test_tile) then wanted_tile = test_tile break end
			end
			if wanted_tile ~= nil then
				local moved = false
				self.anim:set_state("MOVE")
				print("we're moving for fire arm")
				self.anim:set_playback(Playback.Once)
				moved = self:teleport(wanted_tile, ActionOrder.Involuntary, function()
					self.anim:on_complete(function()
						self.anim:set_state("FIREARM_PREP"); self.anim:set_playback(Playback.Loop)
					end)
				end)
				if not moved then self.attack = "FIREBOMB"; self.anim:set_state("FIREBOMB_PREP"); end
			else
				self.attack = "FIREBOMB"
				self.anim:set_state("FIREBOMB_PREP")
				self.anim:set_playback(Playback.Loop)
			end
		elseif self.attack == "FIRETOWER" and own_tile:y() ~= target_tile:y() then
			local wanted_tile = field:tile_at(own_tile:x(), target_tile:y())
			if self.can_move_to_func(wanted_tile) then
				local moved = false
				self.anim:set_state("MOVE")
				print("we're moving for fire tower")
				self.anim:set_playback(Playback.Once)
				moved = self:teleport(wanted_tile, ActionOrder.Involuntary, function()
					self.anim:on_complete(function()
						self.anim:set_state("FIRETOWER_INIT"); self.anim:set_playback(Playback.Loop)
					end)
				end)
				if not moved then self.attack = "FIREBOMB"; self.anim:set_state("FIREBOMB_PREP"); self.anim:set_playback(Playback.Loop); end
			else
				self.attack = "FIREBOMB"
				self.anim:set_state("FIREBOMB_PREP")
				self.anim:set_playback(Playback.Loop)
			end
		end
		if self.attack == "FIREBOMB" then
			self.anim:set_state("FIREBOMB_INIT")
			self.anim:set_playback(Playback.Loop)
		end
		self.firstFrame = false
	else
		if self.attack == "FIREARM" then
			local field = self:get_field()
			if self.waitTime == 205 then
				print("heatup")
				self.anim:set_state("FIREARM_HEATUP")
				self.anim:set_playback(Playback.Loop)
			end
			if self.waitTime == 190 then
				print("firearm")
				self.anim:set_state("FIREARM")
				self.anim:set_playback(Playback.Loop)
				--first fire spawn lasts 190 frames
				field:spawn(Firearm_Fire(self), self:get_tile():x() - 1, self:get_tile():y())
			end
			if self.waitTime == 185 then
				--second fire spawn
				local wanted_tile = field:tile_at(self:get_tile():x() - 2, self:get_tile():y())
				if wanted_tile and not wanted_tile:is_edge() then
					field:spawn(Firearm_Fire(self), self:get_tile():x() - 2, self:get_tile():y())
				end
			end
			if self.waitTime == 180 then
				--third fire spawn
				local wanted_tile = field:tile_at(self:get_tile():x() - 3, self:get_tile():y())
				if wanted_tile and not wanted_tile:is_edge() then
					field:spawn(Firearm_Fire(self), self:get_tile():x() - 3, self:get_tile():y())
				end
			end
			if self.waitTime == 175 then
				--fourth fire spawn
				local wanted_tile = field:tile_at(self:get_tile():x() - 4, self:get_tile():y())
				if wanted_tile and not wanted_tile:is_edge() then
					field:spawn(Firearm_Fire(self), self:get_tile():x() - 4, self:get_tile():y())
				end
			end
			if self.waitTime == 170 then
				--fifth fire spawn
				local wanted_tile = field:tile_at(self:get_tile():x() - 5, self:get_tile():y())
				if wanted_tile and not wanted_tile:is_edge() then
					field:spawn(Firearm_Fire(self), self:get_tile():x() - 5, self:get_tile():y())
				end
			end
		elseif self.attack == "FIRETOWER" then
			if self.waitTime == 206 then
				self.anim:set_state("FIRETOWER_PREP")
				self.anim:set_playback(Playback.Loop)
			end
			if self.waitTime == 160 then
				self.anim:set_state("FIRETOWER")
				self.anim:set_playback(Playback.Loop)
				Engine.play_audio(self.fireTowerSound, AudioPriority.High)
				self:get_field():spawn(Firetower_Fire(self), self:get_tile():x() - 1, self:get_tile():y())
				Engine.play_audio(self.fireTowerSound, AudioPriority.Low)
				self.waitTime = self.waitTime - 100
			end
		elseif self.attack == "FIREBOMB" then
			if self.waitTime == 212 then
				self.anim:set_state("FIREBOMB_PREP_1")
				self.anim:set_playback(Playback.Loop)
			end
			if self.waitTime == 115 then
				self.anim:set_state("FIREBOMB_PREP_2")
				self.anim:set_playback(Playback.Loop)
			end
			if self.waitTime == 100 then
				self.anim:set_state("FIREBOMB")
				self.anim:set_playback(Playback.Loop)
			end
			if self.waitTime == 80 then
				for x = 0, 2 do
					local taken = true
					while taken == true do
						self.bombx[x] = math.random(1, 6)
						self.bomby[x] = math.random(1, 3)
						--check if any previous bombs share a planned location
						taken = false
						for y = 0, x-1 do
							if ((self.bombx[x] == self.bombx[y]) and (self.bomby[x] == self.bomby[y])) then
								taken = true
							end
						end
						if(self:get_field():tile_at(self.bombx[x], self.bomby[x]):get_team() == self:get_team()) then
							taken = true
						end
					end
				end
				Engine.play_audio(self.fireBombLaunchSound, AudioPriority.High)
				self:get_field():spawn(Firebomb(self, self.bombx[0], self.bomby[0]), self:get_tile():x(), self:get_tile():y())
			end
			if self.waitTime == 70 then
				Engine.play_audio(self.fireBombLaunchSound, AudioPriority.High)
				self:get_field():spawn(Firebomb(self, self.bombx[1], self.bomby[1]), self:get_tile():x(), self:get_tile():y())
			end
			if self.waitTime == 60 then
				Engine.play_audio(self.fireBombLaunchSound, AudioPriority.High)
				self:get_field():spawn(Firebomb(self, self.bombx[2], self.bomby[2]), self:get_tile():x(), self:get_tile():y())
			end
			if self.waitTime == 50 then
				self.anim:set_state("FIREBOMB_END")
				self.anim:set_playback(Playback.Loop)
			end
			if self.waitTime == 45 then
				self.waitTime = 0
			end
		end
	end
	if self.waitTime <= 0 then
		NextState(self)
	end
end

function Firearm_Fire(self, firstfire) 
	local fire = Battle.Spell.new(self:get_team())
	fire:set_texture(self.texture, true)
	fire:highlight_tile(Highlight.Solid)
	fire:sprite():set_layer(-1)
	fire:set_facing(self:get_facing())
	fire:set_hit_props(HitProps.new(
        120, 
        Hit.Impact | Hit.Flash | Hit.Flinch, 
        Element.Fire, 
        self:get_context(), 
        Drag.None
        )
    )
	
	local fireAnim = fire:get_animation()
	local expiration = 190

    fireAnim:copy_from(self:get_animation())
    fireAnim:set_state("FIREARM_FIRE_INIT")
    fireAnim:set_playback(Playback.Loop)
	local ref = self
    fire.update_func = function(self, dt) 
		if ref.ruined then self:delete() return end
		if firstfire and expiration%15 == 0 then
			Engine.play_audio(ref.fireArmSound, AudioPriority.High)
		end
		if expiration == 187 then
			fireAnim:set_state("FIREARM_FIRE")
			fireAnim:set_playback(Playback.Loop)
		end
        if expiration < 189 then
			local hitbox = Battle.Hitbox.new(self:get_team())
			hitbox:set_hit_props(fire:copy_hit_props())
			local ymod = 0
			
			fire:get_field():spawn(hitbox, fire:get_tile():x(), fire:get_tile():y() + ymod)
		end
		expiration = expiration - 1
		if expiration <= 0 then
			self:delete()
		end
    end
	
	return fire
end

function Firetower_Fire(self) 
	local fire = Battle.Spell.new(self:get_team())
	fire:set_texture(self.texture, true)
	fire:highlight_tile(Highlight.Solid)
	fire:set_facing(self:get_facing())
	local fireAnim = fire:get_animation()
	local expiration = 139
	
	fire:set_hit_props(
		HitProps.new(
			150, 
			Hit.Impact | Hit.Flash | Hit.Flinch, 
			Element.Fire, 
			self:get_context(), 
			Drag.None
		)
	)

    fireAnim:copy_from(self:get_animation())
    fireAnim:set_state("FIRETOWER_FIRE_INIT")
    fireAnim:set_playback(Playback.Loop)
	local player = self:get_target()
	local ymod = 0
	local ref = self
	local field = self:get_field()
    fire.update_func = function(self, dt) 
		local tile = fire:get_tile()
		if not tile:is_walkable() then self:delete() end
		--3 frames no damage, on 17 spawn next, 137 no more hitbox, 139 despawn
		if expiration == 139 then
			if player:get_tile() then
				if player:get_tile():y() > tile:y() then
					ymod = 1
				end
				if player:get_tile():y() < tile:y() then
					ymod = -1
				end
			end
		end
		if expiration == 123 then
			fireAnim:set_state("FIRETOWER_FIRE")
			fireAnim:set_playback(Playback.Loop)
		end
		if expiration == 4 then
			fireAnim:set_state("FIRETOWER_FIRE_END")
			fireAnim:set_playback(Playback.Loop)
		end
        if expiration < 137 and expiration > 2 then
			tile:attack_entities(self)
			if(tile:is_reserved({})) then
				self:delete()
			end
		end
		if expiration == 122 then
			--playing before checking is game-accurate
			Engine.play_audio(ref.fireTowerSound, AudioPriority.High)
			if tile:x() > 1 then
				field:spawn(Firetower_Fire(ref), tile:x() - 1, tile:y() + ymod)
			end
		end
		expiration = expiration - 1
		if expiration <= 0 then
			self:delete()
		end
    end
	
	fire.collision_func = function(self, other)
		self:delete()
	end
	
	return fire
end

function Firebomb(self, spawnx, spawny) 
	--75 frames to reach ground, [6 frames normal, 2 orange, 2 glowing, 2 orange]x5, 6 normal, [6 normal, 2 glowing, 2 white, 2 glowing]x3, [6 normal, 2 orange, 2 glowing, 10 white]
	local bomb = Battle.Spell.new(self:get_team())
	bomb:set_texture(self.texture, true)
	bomb:show_shadow(true)
	bomb:set_facing(self:get_facing())
	local bombAnim = bomb:get_animation()
	local expiration = 197
	
	local dest = self:get_field():tile_at(spawnx, spawny)

    bombAnim:copy_from(self:get_animation())
    bombAnim:set_state("FIREBOMB_BOMB_1")
    bombAnim:set_playback(Playback.Loop)
	local ref = self
    bomb.update_func = function(self, dt) 
		if expiration == 122 then
			self:get_field():spawn(Firebomb_obstacle(ref), self:get_tile():x(), self:get_tile():y())
			--continue as obstacle
			self:delete()
		end
		expiration = expiration - 1
    end
	
	bomb.can_move_to_func = function(tile)
        return true
    end
	
	bomb:jump(dest, 300.0, frames(75), frames(75), ActionOrder.Voluntary, nil)
	
	return bomb
end

function Firebomb_obstacle(self)
	--75 frames to reach ground, [6 frames normal, 2 orange, 2 glowing, 2 orange]x5, 6 normal, [6 normal, 2 glowing, 2 white, 2 glowing]x3, [6 normal, 2 orange, 2 glowing, 10 white]
	local bomb = Battle.Obstacle.new(self:get_team())
	bomb:set_texture(self.texture, true)
	bomb:show_shadow(true)
	bomb:set_health(10)
	bomb:share_tile(true)
	bomb:set_facing(self:get_facing())
	local bombAnim = bomb:get_animation()
	local expiration = 122
	
    bombAnim:copy_from(self:get_animation())
    bombAnim:set_state("FIREBOMB_BOMB_2")
    bombAnim:set_playback(Playback.Loop)
	local ref = self
    bomb.update_func = function(self, dt) 
		if expiration == 56 then
			bombAnim:set_state("FIREBOMB_BOMB_3")
			bombAnim:set_playback(Playback.Loop)
		end
		if expiration == 20 then
			bombAnim:set_state("FIREBOMB_BOMB_4")
			bombAnim:set_playback(Playback.Loop)
		end
		expiration = expiration - 1
		if expiration <= 0 then
			self:get_field():spawn(Battle.Explosion.new(1, 1.0), bomb:get_tile():x(), bomb:get_tile():y())
			self:get_field():spawn(Firebomb_Fire(ref), bomb:get_tile():x(), bomb:get_tile():y())
			Engine.play_audio(ref.fireBombExplodeSound, AudioPriority.High)
			self:erase()
		end
    end
	bomb.delete_func = function(self) 
		Engine.play_audio(ref.fireBombDieSound, AudioPriority.High)
	end
	
	return bomb
end

function Firebomb_Fire(self)
	local fire = Battle.Spell.new(self:get_team())
	fire:set_texture(self.fireRingTexture, true)

    local ringanim = fire:get_animation()
	ringanim:load(_modpath.."firering.animation")
    ringanim:set_state("IDLE")
    ringanim:set_playback(Playback.Loop)
	fire:highlight_tile(Highlight.Solid)
	
	fire:sprite():set_layer(-2)
	
	fire:set_hit_props(HitProps.new(
        80,
        Hit.Impact | Hit.Flash | Hit.Flinch, 
        Element.Fire, 
        self:get_id(), 
        Drag.None
        )
    )
	
	local expiration = 200

    fire.update_func = function(self, dt) 
		fire:get_tile():attack_entities(self)
		if fire:get_tile():is_reserved({}) and expiration < 200 then
			self:delete()
		end
		expiration = expiration - 1
		if expiration <= 0 then
			self:delete()
		end
    end
	
	fire.collisionFunc = function(self, other)
		self:delete()
	end
	
	return fire
end

function package_init(self)
	self.fireArmSound = Engine.load_audio(_modpath.."firearm.ogg")
	self.fireTowerSound = Engine.load_audio(_modpath.."firetower.ogg")
	self.fireBombLaunchSound = Engine.load_audio(_modpath.."firebomb_launch.ogg")
	self.fireBombDieSound = Engine.load_audio(_modpath.."firebomb_die.ogg")
	self.fireBombExplodeSound = Engine.load_audio(_modpath.."firebomb_explode.ogg")
	local function dayRuined()
		--reset AI pattern when flinched, stunned, etc
		--Does NOT reset his actual attack order! This is new in RV.
		if not self.ruined then
			self.waitTime = 30
			self.anim:set_state("OUCH")
			self.anim:set_playback(Playback.Once)
			self.anim:on_complete(function()
				self.anim:set_state("IDLE")
				self.aiStateIndex = 1
				self.ruined = false
				self.anim:set_playback(Playback.Loop)
			end)
			self.ruined = true
		end
	end
	self.aiStateIndex = 1
	self:register_status_callback(Hit.Flinch, dayRuined)
    self.texture = Engine.load_texture(_modpath.."FireMan.png")
	self.fireRingTexture = Engine.load_texture(_modpath.."firering.png")
	self.activate_function_once = true
	self.attack = nil
	self.attack_order = {"FIREARM", "FIREARM", "FIRETOWER", "FIREBOMB", "FIREBOMB", "FIRETOWER"}
	self.attack_index = 1
	self.can_move_to_func = function(tile)
		if not tile then return false end
		if tile:is_edge() then return false end
		local is_occupied = function(ent) if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then return true end end
		if(tile:is_reserved({}) or (not self:is_team(tile:get_team())) or (not tile:is_walkable())) or #tile:find_entities(is_occupied) > 0 then return false end
		return true
	end
	self.die_once = true
	self.anim = self:get_animation()
    self.anim:load(_modpath.."fireman.animation")
    self.anim:set_state("IDLE")
    self.anim:set_playback(Playback.Loop)
	self.waitTime = 0
	self.update_func = function(self, dt)
		if self:get_health() <= 0 then if self.die_once then self.anim:set_state("FIREBOMB_PREP_1"); self.die_once = false; end return end
		if ruined then return end
		self.waitTime = self.waitTime - 1
		if not self.activate_function_once and not ruined then
			self.activate_function_once = true
		end
		if self.aiStateIndex == 2 or self.aiStateIndex == 6 or self.aiStateIndex == 10 or self.aiStateIndex == 14 then
			WaitState(self, dt)
		elseif self.aiStateIndex == 4 or self.aiStateIndex == 8 or self.aiStateIndex == 12 or self.aiStateIndex == 16 then
			MoveState(self, dt)
		elseif self.aiStateIndex == 18 then
			AttackState(self, dt)
		else
			if self.activate_function_once then
				if self.aiStateIndex == 1 then
					set_wait_timer(self, 25)
				elseif self.aiStateIndex == 3 then
					set_wait_timer(self, 15)
				elseif self.aiStateIndex == 5 then
					set_wait_timer(self, 25)
				elseif self.aiStateIndex == 7 then
					set_wait_timer(self, 15)
				elseif self.aiStateIndex == 9 then
					set_wait_timer(self, 25)
				elseif self.aiStateIndex == 11 then
					set_wait_timer(self, 15)
				elseif self.aiStateIndex == 13 then
					set_wait_timer(self, 45)
				elseif self.aiStateIndex == 15 then
					set_wait_timer(self, 15)
				elseif self.aiStateIndex == 16 then
					MoveState(self, dt)
				elseif self.aiStateIndex == 17 then
					set_wait_timer(self, 215)
				elseif self.aiStateIndex == 18 then
					AttackState(self, dt)
				end
				self.activate_function_once = false
			end
		end
	end
	self.firstFrame = true
	self.bombx = {}
	self.bomby = {}
	self.battle_end_func = function(self)

	end
    self:set_name("FireManRV")
    self:set_health(800)
	self:set_explosion_behavior(11, 1.0, true)
	self:set_element(Element.Fire)
    self:set_texture(self.texture, true)
    self:set_height(60)
    self:share_tile(false)
end