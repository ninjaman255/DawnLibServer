local Volgear="com.louise.char.Volgear"--V1,V2,V3,SP
local KillerEye="com.louise.enemy.KillerEye"--V1SPR1R2
local HauntedCandle="com.louise.enemy.HauntedCandleHauntedCandle"--V1V2V3SPR1R2
local Fishy="com.louise.enemy.Fishy"--V1V2V3SP
local Basher="com.EXE3.Basher.Enemy"--V1
local Catack="com.Dawn.Requested.Enemy.Catack"--V1V2V3SP
local Ratty="com.Dawn.BN3.Enemy.Ratty"--V1V2V3SP
local Champy="com.keristero.char.Champy"
local Mettaur="com.keristero.char.Mettaur"
local Cactikil="com.discord.Konstinople#7692.enemy.cactikil"
local Powie="com.discord.Konstinople#7692.enemy.powie"
local Spikey="com.Dawn.char.Spikey"
local Canodumb="com.discord.Konstinople#7692.enemy.canodumb"

function package_requires_scripts()
    Engine.requires_character(Mettaur)
    Engine.requires_character(Canodumb)
    Engine.requires_character(Spikey)
    Engine.requires_character(Powie)
    Engine.requires_character(Ratty)
    Engine.requires_character(Cactikil)
    Engine.requires_character(Champy)
    Engine.requires_character(Catack)
    Engine.requires_character(HauntedCandle)
    Engine.requires_character(KillerEye)
    Engine.requires_character(Fishy)
    Engine.requires_character(Volgear)
end

function package_init(package) 
    package:declare_package_id("Dawn.ACDC2.VirologistData")
end

function package_build(mob, data)
    local choice = math.random(12)
    if choice == 1 then
        mob:create_spawner(Mettaur, Rank.V2):spawn_at(4, 1)
        mob:create_spawner(Mettaur, Rank.V2):spawn_at(5, 2)
        mob:create_spawner(Mettaur, Rank.V2):spawn_at(4, 3)
    elseif choice == 2 then
        mob:create_spawner(Ratty, Rank.V1):spawn_at(5, 2)
        mob:create_spawner(Canodumb, Rank.V2):spawn_at(6, 1)
        mob:create_spawner(Canodumb, Rank.V2):spawn_at(6, 3)
    elseif choice == 3 then
        mob:create_spawner(Spikey, Rank.V1):spawn_at(4, 1)
        mob:create_spawner(Spikey, Rank.V2):spawn_at(5, 2)
        mob:create_spawner(Spikey, Rank.V3):spawn_at(6, 3)
    elseif choice == 4 then
        mob:create_spawner(Cactikil, Rank.V1):spawn_at(6, 1)
        mob:create_spawner(Cactikil, Rank.V1):spawn_at(6, 3)
    elseif choice == 5 then
        mob:create_spawner(Champy, Rank.V1):spawn_at(5, 1)
        mob:create_spawner(Champy, Rank.V1):spawn_at(4, 3)
    elseif choice == 6 then
        mob:create_spawner(Volgear, Rank.V1):spawn_at(4, 1)
        mob:create_spawner(Volgear, Rank.V1):spawn_at(5, 2)
        mob:create_spawner(Volgear, Rank.V1):spawn_at(6, 3)
    elseif choice == 7 then
        mob:create_spawner(Volgear, Rank.V1):spawn_at(4, 1)
        mob:create_spawner(HauntedCandle, Rank.V1):spawn_at(5, 2)
        mob:create_spawner(Volgear, Rank.V1):spawn_at(6, 3)
    elseif choice == 8 then
        mob:create_spawner(Fishy, Rank.V1):spawn_at(5, 1)
        mob:create_spawner(Fishy, Rank.V1):spawn_at(6, 3)
    elseif choice == 10 then
        mob:create_spawner(Powie, Rank.V1):spawn_at(6, 1)
        mob:create_spawner(Powie, Rank.V1):spawn_at(4, 3)
    elseif choice == 11 then
        mob:create_spawner(KillerEye, Rank.V1):spawn_at(5, 1)
        mob:create_spawner(Basher, Rank.V1):spawn_at(6, 2)
        mob:create_spawner(KillerEye, Rank.V1):spawn_at(5, 3)
    elseif choice == 12 then
        mob:create_spawner(Powie, Rank.V1):spawn_at(4, 1)
        mob:create_spawner(Ratty, Rank.V2):spawn_at(6, 2)
        mob:create_spawner(Cactikil, Rank.V1):spawn_at(5, 3)
    else
        mob:create_spawner(Powie, Rank.V1):spawn_at(4, 1)
        mob:create_spawner(Ratty, Rank.V2):spawn_at(6, 2)
        mob:create_spawner(Cactikil, Rank.V1):spawn_at(5, 3)
    end
end
